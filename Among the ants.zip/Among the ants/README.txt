DESCRIPTION:

Micah: Descent into the Anthill is a 2D top-down, choice-driven adventure game built using Godot 4.4.
You play as Micah, a scientist who mysteriously shrinks to the size of an ant after a lab accident.
Trapped inside a massive ant colony, Micah must explore tunnels, make moral decisions, and survive deadly encounters to find his way out.

Each tunnel offers unique paths, challenges, and consequences — every choice you make shapes Micah’s fate.

-------------------------------------------------------------------------

CONTROLS:

Action		Key

Move		Arrow Keys

Interact	E

Flashlight	F

Balance		A-left/D-right

Pause		Esc

------------------------------------------------------------------------

System Requirements

Minimum:

OS: Windows 10 / Linux
Processor: Intel i3 (or equivalent)
RAM: 4 GB
Graphics: Integrated GPU (supports OpenGL 3.3 or higher)
Storage: 500 MB available space

Recommended:

OS: Windows 11 / Linux (64-bit)
Processor: Intel i5 or higher
RAM: 8 GB
Graphics: Dedicated GPU (NVIDIA/AMD)
Storage: 1 GB available space

----------------------------------------------------------------------

DEVELOPED BY:

Name			GitHub

Ajitesh Rajput	     Ajitesh0712
Ananya Soni	     Ananya-1009
Vedansh Dwivedi	    Vedansh-Dwivedi

B.Tech IT Student — Jaypee Institute of Information Technology, Noida
